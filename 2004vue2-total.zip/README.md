# 2004vue2-total

- 项目依赖的第三方api
  - 查询字符串处理：`npm i -S qs`
  - ajax库：`npm i -S axios`
  - md5算法：`npm i -S spark-md5`
  - 饿了么ui：`npm i -S element-ui`
  - 有赞ui：`npm i -S vant@latest-v2`

- 复制项目后要执行`npm install`初始化一次
